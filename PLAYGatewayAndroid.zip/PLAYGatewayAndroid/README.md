# PLAYGatewayAndroid
App Control CORA MANAGER -  Android

Descarga Cliente Dative ->  java -jar /Users/albertoruiz/Downloads/openapi-generator-cli-5.4.0.jar  generate -i https://priluxwebuiapi.dev-staging.dativepartners.eu/swagger/v1/swagger.json -g kotlin -o /Users/albertoruiz/Desktop/swaggerKotlinOpenAPI  --skip-validate-spec