package cell

data class ItemTextValue(
    var text: String? = "",
    var value: String? = "",
    )