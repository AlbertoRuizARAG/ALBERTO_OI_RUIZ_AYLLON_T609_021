package com.prilux.cmr.global

class ClearBleConnection {


}