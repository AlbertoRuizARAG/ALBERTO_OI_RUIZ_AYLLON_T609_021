package com.prilux.cmr.tests

import androidx.lifecycle.ViewModel

class CmrMainViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}